<?php $__env->startSection('content'); ?>

<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">Products</a> <a href="#" class="current">View Products</a> </div>
    <h1>Products</h1>
     <?php if(Session::has('flash_message_error')): ?>
            <div class="alert alert-error alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong><?php echo session('flash_message_error'); ?></strong>
            </div>        
        <?php endif; ?>
        <?php if(Session::has('flash_message_success')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong><?php echo session('flash_message_success'); ?></strong>
            </div>        
        <?php endif; ?>
  </div>
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>View Products</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>Service ID</th>
                  <th>Category ID</th>
                  <th>Service Name</th>
                  <th>Service Code</th>
                  <th>Price</th>
                  <th>Image</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
              	<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                  <td><?php echo e($product->id); ?></td>
                  <td><?php echo e($product->category_id); ?></td>
                  <td><?php echo e($product->service_name); ?></td>
                  <td><?php echo e($product->service_code); ?></td>
                  <td><?php echo e($product->price); ?></td>
                   <td>
                    <?php if(!empty($product->image)): ?>
                      <img src="<?php echo e(asset('/images/backend_images/products/small/'.$product->image)); ?>" style="width:60px;">
                    <?php endif; ?>
                  </td>   
                  <td class="center">
                     <a href="#myModal<?php echo e($product->id); ?>" data-toggle="modal" class="btn btn-success btn-mini" title="View Product">View</a></div> 
                     <a href="<?php echo e(url('/admin/edit_product/'.$product->id)); ?>" class="btn btn-primary btn-mini" title="Edit Product">Edit</a> 
                      <a rel="<?php echo e($product->id); ?>" rel1="delete_slider_product" <?php /* href="{{url('/admin/delete_category/'.$product->id)}}" */?> href ="javascript:" class="btn btn-danger btn-mini deleteRecord" title="Delete Product">Delete</a>
                  </td>
                </tr>
                    <div id="myModal<?php echo e($product->id); ?>" class="modal hide">
                      <div class="modal-header">
                        <button data-dismiss="modal" class="close" type="button">×</button>
                        <h3><?php echo e($product->service_name); ?> Full Details</h3>
                      </div>
                      <div class="modal-body">
                        <p>Product ID: <?php echo e($product->id); ?></p>
                        <p>Category ID: <?php echo e($product->category_id); ?></p>
                        <p>Product Code:<?php echo e($product->service_code); ?></p>
                        <p>Price: <?php echo e($product->price); ?></p>
                        <p>Description: <?php echo e($product->description); ?></p>
                      </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\FishDesign\resources\views/admin/products/view_slider_products.blade.php */ ?>