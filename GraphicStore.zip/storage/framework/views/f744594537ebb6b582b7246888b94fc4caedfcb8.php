<?php /* C:\xampp\htdocs\FishDesign\resources\views/layouts/adminLayout/admin_footer.blade.php */ ?>
<!--Footer-part-->

<div class="row-fluid">
  <div id="footer" class="span12"> 2013 &copy; Matrix Admin. Brought to you by <a href="http://themedesigner.in">Themedesigner.in</a> </div>
</div>

<!--end-Footer-part-->