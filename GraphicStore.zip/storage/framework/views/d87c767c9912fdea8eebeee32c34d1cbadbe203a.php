<?php $__env->startSection('content'); ?>

<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">Packages</a> <a href="#" class="current">View Packages</a> </div>
    <h1>Packages</h1>
     <?php if(Session::has('flash_message_error')): ?>
            <div class="alert alert-error alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong><?php echo session('flash_message_error'); ?></strong>
            </div>        
        <?php endif; ?>
        <?php if(Session::has('flash_message_success')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong><?php echo session('flash_message_success'); ?></strong>
            </div>        
        <?php endif; ?>
  </div>
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>View Packages</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>Design</th>
                  <th>Designer(s)</th>
                  <th>Revisions</th>
                  <th>Price</th>
                  <th>Image</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
              	<?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                  <td><?php echo e($package->designs); ?></td>
                  <td><?php echo e($package->designers); ?></td>
                  <td><?php echo e($package->revisions); ?></td>
                  <td><?php echo e($package->price); ?></td>
                   <td>
                    <?php if(!empty($package->image)): ?>
                      <img src="<?php echo e(asset('/images/backend_images/products/small/'.$package->image)); ?>" style="width:60px;">
                    <?php endif; ?>
                  </td>   
                  <td class="center">
                     <a href="#myModal<?php echo e($package->id); ?>" data-toggle="modal" class="btn btn-success btn-mini" title="View Product">View</a></div> 
                     <a href="<?php echo e(url('/admin/edit_product/'.$package->id)); ?>" class="btn btn-primary btn-mini" title="Edit package">Edit</a> 
                     <a href="<?php echo e(url('/admin/add_images/'.$package->id)); ?>" class="btn btn-info btn-mini" title="Add Images">Add </a>
                      <a rel="<?php echo e($package->id); ?>" rel1="delete_job" <?php /* href="{{url('/admin/delete_category/'.$product->id)}}" */?> href ="javascript:" class="btn btn-danger btn-mini deleteRecord" title="Delete Product">Delete</a>
                  </td>
                </tr>
                    <div id="myModal<?php echo e($package->id); ?>" class="modal hide">
                      <div class="modal-header">
                        <button data-dismiss="modal" class="close" type="button">×</button>
                        <h3><?php echo e($package->designs); ?> Full Details</h3>
                      </div>
                      <div class="modal-body">
                        <p>Package ID: <?php echo e($package->id); ?></p>
                        <p>Designers:<?php echo e($package->designers); ?></p>
                        <p>Price: <?php echo e($package->price); ?></p>
                        <p>Revisions: <?php echo e($package->revisions); ?></p>
                      </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\FishDesign\resources\views/admin/packages/view_packages.blade.php */ ?>