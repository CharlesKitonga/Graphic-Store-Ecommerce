<?php $__env->startSection('content'); ?>

<div id="content">
  <div id="content-header">
    <div id="breadcrumb"> <a href="index.html" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="#">Jobs</a> <a href="#" class="current">View Jobs</a> </div>
    <h1>Jobs</h1>
     <?php if(Session::has('flash_message_error')): ?>
            <div class="alert alert-error alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong><?php echo session('flash_message_error'); ?></strong>
            </div>        
        <?php endif; ?>
        <?php if(Session::has('flash_message_success')): ?>
            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button> 
                <strong><?php echo session('flash_message_success'); ?></strong>
            </div>        
        <?php endif; ?>
  </div>
    <div class="row-fluid">
      <div class="span12">
        <div class="widget-box">
          <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
            <h5>View Jobs</h5>
          </div>
          <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
              <thead>
                <tr>
                  <th>Job ID</th>
                  <th>Category ID</th>
                  <th>Job Name</th>
                  <th>Job Code</th>
                  <th>Price</th>
                  <th>Image</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
              	<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeX">
                  <td><?php echo e($job->id); ?></td>
                  <td><?php echo e($job->category_name); ?></td>
                  <td><?php echo e($job->staff_name); ?></td>
                  <td><?php echo e($job->job_code); ?></td>
                  <td><?php echo e($job->price); ?></td>
                   <td>
                    <?php if(!empty($job->image)): ?>
                      <img src="<?php echo e(asset('/images/backend_images/products/small/'.$job->image)); ?>" style="width:60px;">
                    <?php endif; ?>
                  </td>   
                  <td class="center">
                     <a href="#myModal<?php echo e($job->id); ?>" data-toggle="modal" class="btn btn-success btn-mini" title="View Product">View</a></div> 
                     <a href="<?php echo e(url('/admin/edit_product/'.$job->id)); ?>" class="btn btn-primary btn-mini" title="Edit job">Edit</a> 
                     <a href="<?php echo e(url('/admin/add_images/'.$job->id)); ?>" class="btn btn-info btn-mini" title="Add Images">Add </a>
                      <a rel="<?php echo e($job->id); ?>" rel1="delete_job" <?php /* href="{{url('/admin/delete_category/'.$product->id)}}" */?> href ="javascript:" class="btn btn-danger btn-mini deleteRecord" title="Delete Product">Delete</a>
                  </td>
                </tr>
                    <div id="myModal<?php echo e($job->id); ?>" class="modal hide">
                      <div class="modal-header">
                        <button data-dismiss="modal" class="close" type="button">×</button>
                        <h3><?php echo e($job->staff_name); ?> Full Details</h3>
                      </div>
                      <div class="modal-body">
                        <p>Job ID: <?php echo e($job->id); ?></p>
                        <p>Category ID: <?php echo e($job->category_name); ?></p>
                        <p>Job Code:<?php echo e($job->job_code); ?></p>
                        <p>Price: <?php echo e($job->price); ?></p>
                        <p>Description: <?php echo e($job->description); ?></p>
                      </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout.admin_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\FishDesign\resources\views/admin/jobs/view_jobs.blade.php */ ?>