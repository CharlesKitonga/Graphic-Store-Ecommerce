<?php $__env->startSection('content'); ?>
<!--breadcrumbs-->
<div class="breadcrumbs">
<div class="container">
	<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
		<li><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
		<li class="active">Categories</li>
	</ol>
</div>
</div>
<!--//breadcrumbs-->
<!--products-->
<div class="products">	 
<div class="container">
	<div class="title-info wow fadeInUp animated" data-wow-delay=".5s">
	<!--gallery-->
<div style="margin-top: -70px;" class="gallery">
	<div class="container">
		<div class="title-info wow fadeInUp animated" data-wow-delay=".5s">
			<h3 class="title">Choose A<span> Package </span></h3>
			<p>Some of the Beautiful Designs We have Done </p>
		</div>
		<div class="gallery-info">
			<?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-3 gallery-grid wow flipInY animated" data-wow-delay=".1.1s" style="margin-right: 10px; margin-top: 25px;">
				<a href="products.html"><img style="width:110px; margin-bottom: 25px;" src="<?php echo e(asset('images/backend_images/products/small/'.$package->image)); ?>" class="img-responsive" alt=""/></a>
				<div class="gallery-text simpleCart_shelfItem">
					<h1><a style="margin-top: 10px; font-family: Helvetica;font-size: 22px;text-align:justify;"  class="name" href="single.html"><?php echo e($package->designs); ?> </a></h1>
					<h2 style="margin-top: 10px; font-family: Helvetica;text-align:justify;" class="name"><?php echo e($package->designers); ?></h2>
					<h3 style="margin-top: 10px; font-family: Helvetica;text-align:justify;" class="name"><?php echo e($package->revisions); ?></h3>
					<h4 style="margin-top: 10px; font-family: Helvetica;text-align:justify;" class="name"><?php echo e($package->gurantee); ?></h4>
					<h5><a style="margin-top: 10px; font-family: Helvetica;text-align:justify;" class="name" style="font-size: 16px;">US$ <?php echo e($package->price); ?> </a></h5>
					<button style="font-size: 26px; margin-top: 20px;" class="label label-success"><a href="<?php echo e(url('/service/'.$package->id)); ?>" > Select</a></button> 
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<div class="clearfix"></div>
		</div>
	</div>
</div>
<!--//gallery-->

	<div class="clearfix"> </div>
</div>
</div>
<!--//products-->		
<script>
function myFunction() {
  document.getElementById("<?php echo e($package->id); ?>").innerHTML = "Selected";
}
</script>
<!-- the jScrollPane script -->
<script type="text/javascript" src="<?php echo e(asset('js/jquery.jscrollpane.min.js')); ?>">
	
</script>

	<script type="text/javascript" id="sourcecode">
		$(function()
		{
			$('.scroll-pane').jScrollPane();
		});
	</script>
<!-- //the jScrollPane script -->
<script type="text/javascript" src="<?php echo e(asset('js/jquery.mousewheel.js')); ?>"></script>
<!-- the mousewheel plugin -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontLayouts.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\FishDesign\resources\views/package.blade.php */ ?>