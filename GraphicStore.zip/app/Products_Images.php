<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Products_Images extends Model
{
    //
}
