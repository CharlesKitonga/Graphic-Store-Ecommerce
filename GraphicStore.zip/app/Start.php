<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Start extends Model
{
    //
}
