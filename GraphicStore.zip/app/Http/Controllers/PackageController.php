<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PackageController extends Controller
{
         public function addPackage(Request $request){

        if ($request->isMethod('post')) {
            $data = $request->all();
            // echo "<pre>";print_r($data); die;
            $packages = new Package;

            $packages->designs = $data['designs'];
            $packages->designers = $data['designer'];
            $packages->revisions = $data['revisions'];
            $packages->gurantee = $data['gurantee'];
            $packages->price =$data['price'];

            //Upload Image
            if ($request->hasFile('image')) {
                $image_tmp = Input::file('image');
                if ($image_tmp->isValid()) {
                    $extension = $image_tmp->getClientOriginalExtension();
                    $filename = rand(111,99999).'.'.$extension;
                    $large_image_path = 'images/backend_images/products/large/'.$filename;
                    $medium_image_path = 'images/backend_images/products/medium/'.$filename;
                    $small_image_path = 'images/backend_images/products/small/'.$filename;
                    // Resize Images
                    Image::make($image_tmp)->save($large_image_path);
                    Image::make($image_tmp)->resize(650,480)->save($medium_image_path);
                    Image::make($image_tmp)->resize(300,300)->save($small_image_path);
                    // Store image name in products table
                    $packages->image = $filename;
                }
            }

            //echo "<pre>";print_r($packages);die;

            $packages->save();
            return redirect()->back()->with('flash_message_success','Package Added Successfuly!');

        }

        return view('admin.packages.add_package');
    }
       public function viewPackages(Request $request){

        $packages = Package::get();
        $packages = json_decode(json_encode($packages));
        // foreach($products as $key => $val){
        //     $category_name = Category::where(['id'=>$val->category_id])->first();
        //     $products[$key]->category_name = $category_name->category_name;
        // }
        // echo "<pre>"; print_r($products); die;
        return view('admin.packages.view_packages')->with(compact('packages'));
    }
}
