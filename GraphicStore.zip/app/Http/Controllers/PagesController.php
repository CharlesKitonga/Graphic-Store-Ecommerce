<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

use Image;
use DB;
use App\SliderImages;
use App\Product;
use App\Category;
use App\Job;
use App\Start;
use App\Package;
class PagesController extends Controller
{
    public function Index($id = null){


    	//In Ascending Order  (by Default)
    	$allServices = Product::get();

    	//In Descending Order 
    	$allServices = Product::OrderBy('id','DESC')->get();

    	//In Random Order 
    	$allServices = Product::inRandomOrder()->get();


        //Work Done In Random Order 
        $jobsdone = Job::inRandomOrder()->get();


        //Get Slider Images
        $sliderimages = SliderImages::get();
        $sliderimages = json_decode(json_encode($sliderimages));

        //Get Product Details
        $serviceDetails = Product::where('id',$id)->first();
        $serviceDetails = json_decode(json_encode($serviceDetails));

    	//Get all categories and subcategories
    	$categories = Category::with('categories')->where(['parent_id'=>0])->get();
        // $categories = json_decode(json_encode($categories));
        

    	return view('index')->with(compact('allServices','sliderimages','categories_menu','productDetails','jobsdone','categories'));
    }

    public function viewProducts(Request $request){

        
        //Work Done In Random Order 
        $jobsdone = Job::inRandomOrder()->get();
        // echo "<pre>"; print_r($jobsdone); die;
        return view('products')->with(compact('jobsdone'));
    }

    public function Start(Request $request, $id=null){
        if ($request->isMethod('post')) {
            $data = $request->all();
            // Upload Image
            $file = Input::file('image');
            $imageName = Input::file('image');
            $imageName = $imageName->getClientOriginalName();
            $destination = 'images/';
            $file->move($destination, $imageName);

            $starts = new Start;
            $starts->project = $data['project'];
            $starts->description = $data['description'];
            $starts->image = $imageName;
             // echo "<pre>";print_r($starts);die;
            $starts->save();
        }
        $categories = Product::where(['id'=>$id])->first();
        //$categories = json_decode(json_encode($categories));
        return view('start')->with(compact('categories'));
    }

    public function Package(){

        $packages = Package::get();

        
        return view('package')->with(compact('packages'));
    }


}
